﻿from ._cshogi import *
